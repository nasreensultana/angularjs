<?php 

	defined('BASEPATH') OR exit('No direct script access allowed');
	class Register extends CI_Controller{

		public function __construct(){
			parent :: __construct();
			$this->load->helper('url');
			$this->load->helper('form');
			$this->load->model('Register_model');
			$this->load->database();
		}

		public function index(){
			$this->load->view('school/register.php');
		}

		public function register_user(){
			$this->load->library('form_validation');
			//basic required field
			$this->form_validation->set_rules('first_name','First Name','required');
			$this->form_validation->set_rules('last_name','Last Name','required');
			$this->form_validation->set_rules('email','Email Field','required|valid_email|min_length[5]|max_length[125]');
			//password fiels with confirmation field matching
			$this->form_validation->set_rules('password1','Password One','required|min_length[5]|max_length[30]');
			$this->form_validation->set_rules('password2','Password Two','required|matches[password1]');
			
			if($this->form_validation->run()==FALSE){
					redirect('Register');
			}
			else {
			$data = array(
				'user_first_name' => $this->input->post('first_name'),
				'user_last_name' => $this->input->post('last_name'),
				'user_email' => $this->input->post('email'),
				'user_password' => $this->input->post('password1')
			);
			
				//print_r($data);
				if($this->Register_model->register_user($data)){
					redirect('Signin');
				}
				else {
					$this->load->view('school/register.php');
				}
			
			}
		}
	}
	
 ?>