<?php echo anchor('signin/logout', 'Logout'); ?>

<br />
<br />

Success! Logged in as <?php echo $this->session->userdata('user_email'); ?>