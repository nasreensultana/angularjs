<?php echo form_open('register/register_user'); ?>
<?php if (validation_errors()): ?>
    	<h3> Whoops! There was an error: </h3>
    <?php endif; ?>

	<table>
		<tr>
			<td>First Name</td>
			<td>
				<?php 
					echo form_input(
						array(
							'name' => 'first_name',
							'id' => 'first_name',
							'value' => set_value('first_name',''),
							'style' => 'width: 100%'
						)
					);
				 ?>
                 <?php echo form_error('first_name'); ?>
			</td>
		</tr>
		<tr>
			<td>Last Name</td>
			<td>
				<?php 
					echo form_input(
						array(
							'name' => 'last_name',
							'id' => 'last_name',
							'value' => set_value('last_name',''),
							'style' => 'width: 100%'
						)
					);
				 ?>
                 <?php echo form_error('last_name'); ?>
			</td>
		</tr>
		<tr>
			<td>User Email</td>
			<td>
				<?php 
					echo form_input(
						array(
							'name' => 'email',
							'id' => 'email',
							'value' => set_value('email',''),
							'style' => 'width: 100%'
						)
					);
				 ?>
                 <?php echo form_error('email'); ?>
			</td>
		</tr>
		<tr>
			<td>Password</td>
			<td>
				<?php 
					echo form_input(
						array(
							'name' => 'password1',
							'id' => 'password1',
							'value' => set_value('password1',''),
							'style' => 'width: 100%'
						)
					);
				 ?>
                 <?php echo form_error('password1'); ?>
			</td>
		</tr>
		<tr>
			<td>Confirm Password</td>
			<td>
				<?php 
					echo form_input(
						array(
							'name' => 'password2',
							'id' => 'password2',
							'value' => set_value('password2',''),
							'style' => 'width: 100%'
						)
					);
				 ?>
                 <?php echo form_error('password2'); ?>
			</td>
		</tr>
	</table>
	<?php echo form_submit('submit','submit'); ?>
<?php echo form_close(); ?>