<?php 

	defined('BASEPATH') OR exit('No direct script access allowed');
	class Signin extends CI_Controller{

		public function __construct(){
			parent :: __construct();
			$this->load->helper('url');
			$this->load->helper('form');
			$this->load->library('session');
			$this->load->library('form_validation');
			$this->load->database();
		}

		public function index(){
			$this->load->view('signin/signin.php');
		}

		public function signin(){
			//set validation rules for view filters
			$this->form_validation->set_rules('email','Email','required|valid_email|min_length[5]|max_length[125]');
			//password fiels with confirmation field matching
			$this->form_validation->set_rules('password','Password','required|min_length[5]|max_length[30]');
			
			if($this->form_validation->run()==FALSE){
				$this->load->view('signin/signin.php');
			}
			else {
				$email = $this->input->post('email');
				$password = $this->input->post('password');
				$this->load->model('Signin_model');
				$query = $this->Signin_model->dows_user_exist($email);
				if($query->num_rows()>=1){
					foreach($query->result()as $row){
						//print_r($row);
						if($row->user_password == $password){
							//print "Tahole Besh";
							$data = array(
								'user_id' => $row->user_id,
								'user_email' => $row->user_email,
								'logged_in' => TRUE
							);
							//Save data to session
							$this->session->set_userdata($data);
							redirect('signin/loggedin');
						}
						else {
							$this->load->view('signin/signin.php');	
						}
					}
				}
				else {
					print "Uni Nei";
				}
			}
		}
		public function loggedin(){
			if($this->session->userdata('logged_in') == TRUE){
				$this->load->view('signin/loggedin');	
			}
			else {
				redirect('signin');	
			}
		}
		
		public function logout(){
			$this->session->sess_destroy();
			redirect('signin');	
		}
		
		public function forgot_password(){
			$this->form_validation->set_rules('email','Email','required|valid_email|min_length[5]|max_length[125]');
			if($this->form_validation->run() == FALSE){
				$this->load->view('signin/forgot_password');
			}
			else {
				print "Besh";
			}
		}
	}

 ?>