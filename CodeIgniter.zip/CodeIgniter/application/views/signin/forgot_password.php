<?php echo form_open('signin/forgot_password'); ?>
    
	<table border="0">
		<tr>
			<td>User Email</td>
			<td>
				<?php echo form_input(
						array(
							'name' => 'email',
							'id' => 'email',
							'value' => set_value('email',''),
							'maxlength' => '100', 
							'size' => '50',
							'style' => 'width: 100%'
						)
					); ?>
				<?php echo form_error('email'); ?>
			</td>
		</tr>
	</table>
	<?php echo form_submit('submit','Submit'); ?>
	or <?php echo anchor('signin','Cancel'); ?>
	<?php echo form_close(); ?>