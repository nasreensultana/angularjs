<?php echo form_open('Shop'); ?>
<select name="cat">
	<option value="">Select</option>
<?php

	//print_r($cat_query);
	foreach($cat_query->result() as $cat){ ?>
		<option value="<?php echo $cat->cat_id; ?>">
			<?php echo $cat->cat_name; ?>
        </option>	
	<?php } ?>
</select>
	<?php echo form_submit('submit','Submit'); ?>
  
<table border="1" cellpadding="10">    
<?php

	foreach($query->result() as $cat){
		echo "<tr>
		<td>" . $cat->product_name . "</td>
		<td>" . $cat->product_price . "</td>
		<td>" . $cat->category_id . "</td>";
	?>
    <td>
    <?php echo anchor('shop/add/'.$cat->product_id,'Add to cart'); ?>
		<?php "</td></tr>";
	}

?>
</table>

