

 <!-- Container (About Section)  -->
<div id="about" class="container">
	<div class="row">
		<div class="col-sm-8">
			<h2><?php echo $heading; ?></h2>
			<h4><?php echo $heading1; ?></h4>
			<p><?php echo $content; ?></p>
		</div>
		<div class="col-sm-4">
			<?php 
				foreach($img as $im){ ?>
					<p><img src="<?php echo base_url().'image/'.$im; ?>" style="width: 100%;" ></p>			
				<?php } ?>
		</div>
	</div>
</div>



