<?php

	defined('BASEPATH') OR exit('No direct script access allowed');
	class Tomadi extends CI_Controller{

		public function __construct(){
			parent :: __construct();
			$this->load->helper('url');
		}

		public function index(){
				$title['school_title']="NS School";
				$title['menus']= array('Gallery','About','Career','Contact','Login');
				//$title['bdy1']= 'Basic Navbar Example';	
				//$title['bdy2']= 'A navigation bar is a navigation header that is placed at the top of the page.';
				$title['active_img']= '18.png';
				$title['img']= array('16.jpg','17.png');
				$this->load->view('school/header');
				$this->load->view('school/menu', $title);
				$this->load->view('school/body', $title);
				$this->load->view('school/footer');				
			}
		public function Gallery(){
				$title['school_title']="NS School";
				$title['menus']= array('Gallery','About','Career','Contact','Login');
				$title['bdy1']= 'Gallery Page';	
				$title['bdy2']= '';
				$this->load->view('school/header');
				$this->load->view('school/menu', $title);
				$this->load->view('school/gallery', $title);
				$this->load->view('school/footer');	
			}
			
		public function About(){
				$title['school_title']="NS School";
				$title['menus']= array('Gallery','About','Career','Contact','Login');
				$title['heading']= 'About Us Page';	
				$title['heading1']= 'The use of the term school varies by country, as do the names of the various levels of education within the country.';
				$title['content']= 'Under the British rule in India, Christian missionaries from England, USA and other countries established missionary and boarding schools throughout the country. Later as these schools gained in popularity, more were started and some gained prestige. These schools marked the beginning of modern schooling in India and the syllabus and calendar they followed became the benchmark for schools in modern India. Today most of the schools follow the missionary school model in terms of tutoring, subject / syllabus, governance etc.with minor changes.';
				$title['img']=array('15.jpeg','16.jpg');		
				$this->load->view('school/header');
				$this->load->view('school/menu', $title);
				$this->load->view('school/about', $title);
				$this->load->view('school/footer');	
			}
		
		public function Career(){
				$title['school_title']="NS School";
				$title['menus']= array('Gallery','About','Career','Contact','Login');
				$title['bdy1']= 'Career Page';	
				$title['bdy2']= '';											
				$this->load->view('school/header');
				$this->load->view('school/menu', $title);
				$this->load->view('school/career', $title);
				$this->load->view('school/footer');						
			}
	
		public function Contact(){
				$title['school_title']="NS School";
				$title['menus']= array('Gallery','About','Career','Contact','Login');
				$title['bdy1']= 'Contact Us Page';	
				$title['bdy2']= '';											
				$this->load->view('school/header');
				$this->load->view('school/menu', $title);
				$this->load->view('school/contact', $title);
				$this->load->view('school/footer');			
			}
		
		public function Login(){
			redirect('signin');	
		}					
		
	}

?>