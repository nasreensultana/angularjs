<?php echo form_open('Shop/index'); ?>
<select name="cat">
	<option value="">Select</option>
<?php

	//print_r($cat_query);
	foreach($cat_query->result() as $cat_row): ?>
		<option value="<?php echo $cat_row->cat_id; ?>">
			<?php echo $cat_row->cat_name; ?>
        </option>	
	<?php endforeach; ?>
</select>
<?php echo form_submit('','Search'); ?>
<?php form_close(); ?>


<?php echo form_open('Shop/update_cart'); ?>
<table border="1" cellpadding="7">
	<tr>
    	<th>ID</th>
        <th>Quantity</th>
        <th>Name</th>
        <th>Price</th>
        <th>Subtotal</th>
    </tr>

<?php 
	
	$i=1;
	foreach($this->cart->contents() as $items){
		echo form_hidden($i.'[rowid]',$items['rowid']);
		print "<tr><td>" . $items['id'] . "</td>";
		print "<td>" . form_input(array('name'=>$i.'[qty]', 'value'=>$items['qty'])). "</td>";
		print "<td>" . $items['name'] . "</td>";
		print "<td>" . $this->cart->format_number($items['price']) . "</td>";
		print "<td>" . $this->cart->format_number($items['subtotal']) . "</td></tr>";
		$i++;
	}

?>

</table>
<div style="margin-left:325px;">
	<b>
    	Total: 
			<?php 
				print $this->cart->format_number($this->cart->total()); 
			?>
    </b>
</div>
<?php echo form_submit('submit','Submit'); ?>
<?php form_close(); ?>