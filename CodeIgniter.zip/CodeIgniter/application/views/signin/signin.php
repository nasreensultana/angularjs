<?php echo form_open('Signin/signin'); ?>
<?php if (validation_errors()): ?>
    	<h3> Whoops! There was an error: </h3>
    <?php endif; ?>
    
	<table border="0">
		<tr>
			<td>User Email</td>
			<td>
				<?php echo form_input(
						array(
							'name' => 'email',
							'id' => 'email',
							'value' => set_value('email',''),
							'maxlength' => '100', 
							'size' => '50',
							'style' => 'width: 100%'
						)
					); ?>
				<?php echo form_error('email'); ?>
			</td>
		</tr>
		<tr>
			<td>Password</td>
			<td>
				<?php echo form_password(
						array(
							'name' => 'password',
							'id' => 'password',
							'value' => set_value('password',''),
							'maxlength' => '100', 
							'size' => '50',
							'style' => 'width: 100%'
						)
					); ?>
				<?php echo form_error('password'); ?>					
			</td>
		</tr>	
	</table>
	<?php echo form_submit('submit','Sign in'); ?>
	or <?php echo anchor('signin','Cancel'); ?>
	<?php echo anchor('signin/forgot_password','Forgot Password'); ?>
	<?php echo form_close(); ?>
	<?php echo anchor('Register','Sign Up'); ?>