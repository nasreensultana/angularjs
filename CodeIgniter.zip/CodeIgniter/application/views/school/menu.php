<nav class="navbar navbar-inverse">
  <div class="container">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">
	  	<?php 
			$base_url = base_url();
			echo $school_title; 
		?></a>
    </div>
    <ul style="float:right" class="nav navbar-nav">
      <li style="float:left" class="active"><a href="<?php echo $base_url.'index.php/Tomadi/'; ?>">Home</a></li>
      <?php foreach($menus as $menu){ ?>
      			<li><a href="<?php echo $base_url."index.php/Tomadi/".$menu; ?>"><?php echo $menu; ?></a></li>		  	
		  <?php } ?>
    </ul>
  </div>
</nav>